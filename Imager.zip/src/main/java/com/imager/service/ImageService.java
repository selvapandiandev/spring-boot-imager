package com.imager.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.FileSystemUtils;

import com.imager.pojo.Image;

import reactor.core.publisher.Flux;

@Service
public class ImageService {

	private static final String UPLOAD_ROOT = "upload-dir";
	
	private ResourceLoader resourceLoader;

	public ImageService(ResourceLoader resourceLoader) {
		this.resourceLoader = resourceLoader;
	}
	
	CommandLineRunner setUp() throws IOException{
		return (args) -> {
			FileSystemUtils.deleteRecursively(new File(UPLOAD_ROOT));
			Files.createDirectory(Paths.get(UPLOAD_ROOT));
			FileCopyUtils.copy("Test file1", new FileWriter(UPLOAD_ROOT+"/swathy.jpg"));
			FileCopyUtils.copy("Test file2", new FileWriter(UPLOAD_ROOT+"/skanda.jpg"));
		};
	}
	
	public Flux<Image> findAllImages() {
		try {
			return Flux.fromIterable(
					Files.newDirectoryStream(Paths.get(UPLOAD_ROOT)))
					.map(path -> 
					new Image(path.hashCode(), path.getFileName().toString()));
		}catch (IOException e) {
			return Flux.empty();
		}
	}
	
	
}
